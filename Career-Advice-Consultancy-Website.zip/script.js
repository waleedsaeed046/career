document.addEventListener('DOMContentLoaded', function() {
  console.log('Career Advice Consultancy website loaded.');
});
